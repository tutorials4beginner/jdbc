
MiniConnectionPoolManager
=========================

MiniConnectionPoolManager is a lightweight standalone Java JDBC connection
pool manager.

Project home page: http://www.source-code.biz/miniconnectionpoolmanager